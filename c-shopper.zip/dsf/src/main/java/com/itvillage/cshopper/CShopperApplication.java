package com.itvillage.cshopper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CShopperApplication {

	public static void main(String[] args) {
		SpringApplication.run(CShopperApplication.class, args);
	}

}
