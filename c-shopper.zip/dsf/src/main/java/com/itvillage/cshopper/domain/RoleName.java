package com.itvillage.cshopper.domain;

public enum RoleName {
    SUPER_ADMIN,
    ADMIN,
    SUB_ADMIN
}
