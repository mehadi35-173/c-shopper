package com.itvillage.cshopper.util;

import java.util.UUID;

public class UuidUtil {

    public String getUuidUtil(){
        return UUID.randomUUID().toString();
    }
}
