package com.itvillage.cshopper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CShopperApplicationTests {

	@Test
	void contextLoads() {
	}

}
